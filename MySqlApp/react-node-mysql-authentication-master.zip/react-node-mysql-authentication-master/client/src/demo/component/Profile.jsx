import React from 'react';
// import {NavLink} from 'react-router-dom';

const Profile = () => {
  return (
    <>
    <section style={{
      backgroundColor:'royalblue',
      width:'100%',
      height:'90vh'
    }}>
     <div className="box">
      
      <h1>WELCOME TO REACT PROFILE</h1>
    
     </div>
      
      
      </section>      
    </>
  )
}

export default Profile;
